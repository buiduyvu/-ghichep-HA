## Ghi chép về Pacemaker và Corosync

[1. Giới thiệu và hướng dẫn cài đặt mô hình 2 node] (https://github.com/hoangdh/ghichep-HA/blob/master/Pacemaker_Corosync/1.Huong-dan-cai-dat-Pacemaker-Corosync.md)

[2. Script cài đặt mô hình Active - Passive 2 node] (https://github.com/hoangdh/ghichep-HA/tree/master/Pacemaker_Corosync/Script)