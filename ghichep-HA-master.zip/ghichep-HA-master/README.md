## Một vài ghi chép về HA

[1. Ghi chép HAProxy](https://github.com/hoangdh/ghichep-HA/tree/master/HAProxy)

*Phần này sẽ giới thiệu tổng quan về HAProxy, phân tích luồng hoạt động và các bước cài đặt HAProxy + Keepalived để triển khai cân bằng tải cho dịch vụ Web server.*

[2. Ghi chép Pacemaker và Corosync](https://github.com/hoangdh/ghichep-HA/tree/master/Pacemaker_Corosync)

*Tổng hợp lại những thông tin về Pacemaker, các bước cài đặt dịch vụ để quản lý tài nguyên phục vụ cho việc HA Web server. Đi kèm là script cài đặt tự động.*