## Ghi chép về HAProxy

[1. Giới thiệu và Phân tích luồng hoạt động của HAProxy] (https://github.com/hoangdh/ghichep-HA/blob/master/HAProxy/1.Phan-tich-hoat-dong-cua-HAProxy.md)

*Giúp các bạn hiểu hơn về luồng làm việc của HAProxy trong quá trình cân bằng tải.*

[2. Cài đặt Keepalived và load-balancer cho Web Server] (https://github.com/hoangdh/ghichep-HA/blob/master/HAProxy/2.Huong-dan-cai-dat-HA.md)

*Hướng dẫn cài đặt HAProxy với Keepalived làm nhiệm vụ cân bằng tải cho các Webserver.*